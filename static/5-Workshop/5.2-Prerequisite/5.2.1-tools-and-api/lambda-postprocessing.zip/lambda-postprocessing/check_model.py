import urllib.request
import json

# THAY CHUỖI DƯỚI ĐÂY BẰNG API KEY THẬT CỦA BẠN (Cái mà bạn đã cấu hình trên AWS Secrets Manager)
API_KEY = "API KEY CỦA BẠN"

url = f"https://generativelanguage.googleapis.com/v1beta/models?key={API_KEY}"
try:
    print("Đang kết nối đến Google Gemini API để kiểm tra...")
    with urllib.request.urlopen(url) as response:
        data = json.loads(response.read().decode())
        print("\n=== CÁC MODEL BẠN CÓ THỂ DÙNG TRONG CODE ===")
        found = False
        for model in data.get('models', []):
            name = model.get('name')
            if 'generateContent' in model.get('supportedGenerationMethods', []):
                print(f"- {name.replace('models/', '')}")
                found = True
        
        if not found:
            print("Tài khoản của bạn chưa được cấp quyền sử dụng model nào để tạo text.")
except urllib.error.HTTPError as e:
    print(f"Lỗi kết nối (HTTP {e.code}): Hãy kiểm tra lại xem API Key đã chính xác chưa.")
except Exception as e:
    print("Lỗi:", e)
